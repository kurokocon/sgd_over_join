import psycopg2
import subprocess
import os
import time


nR = 40000000
dS = 5
#tuple ratio
tr = 10
#feature ratio
fr = 3
num_epoch = 10
VERBOSE = False
data_log = open('gen_data.log', 'w')
log_counter = 0	

class DBInterface(object) :
	def __init__(self) :
		# connect DB using default connect string
		self.conn = psycopg2.connect('')

	def __del__(self) :
		self.conn.commit()
		self.conn.close()

	def execute(self, query) :
		cursor = self.conn.cursor()
		if VERBOSE :
			print 'executing: ', query
		cursor.execute(query)
		cursor.close()

	def execute_and_fetch(self, query) :
		cursor = self.conn.cursor()
		if VERBOSE :
			print 'executing: ', query
		cursor.execute(query)
		ret = cursor.fetchall()
		cursor.close()
		return ret

def getNumChunk():
	DB = DBInterface()
	content = DB.execute_and_fetch("explain select * from s,r where r.rid=s.forkey");
	for i in content:
		if 'Explain batches' in i[0]:
			return int(i[0].split(' ')[2])
	return ''

def updateSpec(approach, dS, dR, num_chunk):
	global log_counter
	output = ''
	for line in open('example_spec.py'):
		if 'dS' in line:
			slist = line.split(' ')
			output += slist[0] + ' ' + slist[1] + ' ' + str(dS) + '\n'
		elif 'dR' in line:
			slist = line.split(' ')
			output += slist[0] + ' ' + slist[1] + ' ' + str(dR) + '\n'
		elif 'approach' in line:
			slist = line.split(' ')
			output += slist[0] + ' ' + slist[1] + ' ' + "\'" + approach + "\'" + '\n'
		elif 'num_partition' in line:
			slist = line.split(' ')
			output += slist[0] + ' ' + slist[1] + ' ' + str(num_chunk) + '\n'
		else:
			output += line
	file = open(str(log_counter) + "_spec.log", 'w')
	file.write(output)
	file.close()
	log_counter += 1
	file = open("example_spec.py", 'w')
	file.write(output)
	file.close()
for fr in [10,6]:
	dR = int(dS * fr)
	print "Gen data"
	program = subprocess.Popen('./gen_data {0} {1} {2} {3} 1.0 s r'.format(tr, nR, dS, dR), stdout=data_log, stderr=data_log,shell=True)
	program.wait()
	print "Move data"
	program = subprocess.Popen('mv s ../etl/', shell=True)
	program.wait()
	program = subprocess.Popen('mv r ../etl/', shell=True)
	program.wait()
	print "go to etl"
	os.chdir('../etl/')
	time.sleep(1)
	print "Load table"
	program = subprocess.Popen('bash example_etl.sh', stdout=data_log, shell=True)
	program.wait()
	print "go to bin"
	os.chdir('../bin/')
	num_chunk = getNumChunk()
	for approach in ['m','hpis']:
		print "Update spec for " + approach
		updateSpec(approach, dS, dR, num_chunk)
		print "Run front end"
		time.sleep(1)
		program = subprocess.Popen('bash example_run.sh {0}_fr_{1}_sonce.out'.format(fr, approach), shell=True)
		program.wait()
	print "Back to script"
	os.chdir('../experiment_script/')
