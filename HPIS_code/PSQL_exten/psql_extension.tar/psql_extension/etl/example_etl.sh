psql -f example_create_tables.sql
sh example_load_tables.sh
